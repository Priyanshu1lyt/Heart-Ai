# Heart AI

A private Android workspace for Minecraft resource-pack and mod projects.

## First milestone
- Native Android app shell built with Kotlin and Jetpack Compose
- Texture Pack Studio, Mod Workshop, and GitHub Projects entry points
- GitHub Actions workflow to build a debug APK

## Build
Upload this project to your GitHub repository. Open the Actions tab and run
**Build Heart AI Android APK**. Download the artifact named `Heart-AI-debug-apk`.

## Current limitations
This is only the starter UI. AI generation, GitHub authorization, file editing,
Minecraft pack export, and automated mod builds are not connected yet. The chat
currently shows a setup notice and does not call an AI model.

## Security
Do not commit GitHub tokens, API keys, passwords, or other secrets. Future
GitHub integration should use narrowly scoped authorization and keep credentials
out of source code.
