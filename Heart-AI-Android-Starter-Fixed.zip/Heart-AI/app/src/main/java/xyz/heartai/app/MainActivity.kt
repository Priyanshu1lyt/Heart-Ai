package xyz.heartai.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF101522)
private val Panel = Color(0xFF1A2233)
private val Cyan = Color(0xFF55D6E8)
private val Muted = Color(0xFF9BA9BE)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { HeartAiApp() }
    }
}

@Composable
fun HeartAiApp() {
    var prompt by remember { mutableStateOf("") }
    var messages by remember {
        mutableStateOf(listOf("Welcome! Heart AI is ready for your Minecraft project ideas."))
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Ink, surface = Panel, primary = Cyan,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Surface(modifier = Modifier.fillMaxSize(), color = Ink) {
            Column(Modifier.fillMaxSize().padding(20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("HEART", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black)
                    Text(" AI", color = Cyan, fontSize = 25.sp, fontWeight = FontWeight.Black)
                    Spacer(Modifier.weight(1f))
                    Surface(color = Panel, shape = RoundedCornerShape(50)) {
                        Text("PRIVATE BUILD", color = Cyan,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                            fontSize = 10.sp)
                    }
                }
                Text("Your Minecraft creation workspace", color = Muted, fontSize = 13.sp)
                Spacer(Modifier.height(22.dp))
                Text("What are we building today?", color = Color.White,
                    fontSize = 21.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                FeatureCard(Icons.Default.Palette, "Texture Pack Studio",
                    "Plan textures, item sets and pack layouts.")
                FeatureCard(Icons.Default.Code, "Mod Workshop",
                    "Generate and organize mod source code.")
                FeatureCard(Icons.Default.Folder, "GitHub Projects",
                    "Connect a repository and manage project files.")
                Spacer(Modifier.height(18.dp))
                Text("WORKSPACE CHAT", color = Cyan, fontSize = 11.sp,
                    fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                LazyColumn(
                    modifier = Modifier.weight(1f).fillMaxWidth()
                        .background(Panel, RoundedCornerShape(16.dp)).padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(messages.size) { index ->
                        Text(messages[index], color = Color.White, fontSize = 14.sp)
                    }
                }
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = prompt, onValueChange = { prompt = it },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("Describe your Minecraft project…") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Cyan, unfocusedBorderColor = Muted,
                            focusedTextColor = Color.White, unfocusedTextColor = Color.White
                        )
                    )
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = {
                        if (prompt.isNotBlank()) {
                            messages = messages + "You: $prompt" +
                                "Heart AI: AI generation will be connected in a later milestone."
                            prompt = ""
                        }
                    }) { Text("Send") }
                }
                Spacer(Modifier.height(6.dp))
                Text("Starter UI • AI and GitHub features are not connected yet.",
                    color = Muted, fontSize = 10.sp)
            }
        }
    }
}

@Composable
private fun FeatureCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String
) {
    Surface(color = Panel, shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = Cyan, modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(12.dp))
            Column {
                Text(title, color = Color.White, fontWeight = FontWeight.SemiBold)
                Text(subtitle, color = Muted, fontSize = 12.sp)
            }
        }
    }
}
